#' (DEPRECATED) Writes a data.frame's schema to Dataiku's Data Science Studio
#' @export
write.dataset_schema <- function (df,name) {
    .Deprecated("dkuWriteDatasetSchema")
    stop("Please switch to dkuWriteDatasetScheam()")
}