escape.shell.arg <- function(arg) {
    # This is the worst escaping function ever.
    # I don't know R.
    # I don't want to learn R.
    # If you have a better solution, feel free to destroy this shit !
    escaped = "'"
    for(i in 1:nchar(arg)) {
        c <- substr(arg,i,i)
        if(c=="'") {
            escaped <- paste0(escaped,"'\\''")
        } else {
            escaped <- paste0(escaped,c)
        }
    }
    escaped <- paste0(escaped,"'")
    return(escaped)
}