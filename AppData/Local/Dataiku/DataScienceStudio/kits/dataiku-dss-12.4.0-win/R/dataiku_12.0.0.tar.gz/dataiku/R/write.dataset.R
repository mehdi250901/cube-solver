#' (DEPRECATED) Writes a data.frame to Dataiku's Data Science Studio
#' 
#' @param df The data.frame to write to Data Science Studio
#' @param name The name of the dataset in data science studio to write to
#' @param partition The name of the partition to write to. Optional
#'
#' @return None
#'
#' @details
#'
#' This function writes a dataset to Dataiku's Data Science Studio. 
#' 
#' Please see Dataiku's online documentation for 
#' a description of how to use partitions in combination with R.
#' 
#' Please note that this function is now deprecated. Please use dkuWriteDataset.
#' 
#' @examples
#' \dontrun{
#' # write the iris dataset to Data Science Studio
#' write.dataset(iris, "irisDataiku")
#'
#' # write dataset to a partition of the 'counts' dataset 
#' df = data.frame(x=c(1,2,3,4))
#' write.dataset(df, "counts", partition="2015-01-01")
#' }
#' @export

write.dataset <- function (df,name,partition="") {
    .Deprecated("dkuWriteDataset")
    stop("Please switch to dkuWriteDataset()")
}