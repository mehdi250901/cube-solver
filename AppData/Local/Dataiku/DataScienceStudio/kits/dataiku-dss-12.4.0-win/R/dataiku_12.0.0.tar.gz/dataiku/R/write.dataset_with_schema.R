#' (DEPRECATED) Writes a data.frame and its schema to Dataiku's Data Science Studio
#' @export
write.dataset_with_schema <-
function (df,name,partition="") {
     .Deprecated("dkuWriteDataset")
     stop("Please switch to dkuWriteDataset()") 
}