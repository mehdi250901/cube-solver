full.sampling <- function() {
    sampling <- {}
    sampling$samplingMethod <- "FULL"
    return(sampling)
}